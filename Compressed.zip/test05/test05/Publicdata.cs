﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test05
{
    class Publicdata
    {
        public static string PStudName = "";
        public static DateTime PStudBirth;
        public static string PStudGPA = "";
        public static bool PStudStat;

    }
}
